<?php
include "db.php";

if(isset($_POST['signup'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        $error = "Email already registered!";
    } else {
        mysqli_query($conn, "INSERT INTO users(email,password,role) VALUES('$email','$password','user')");
        $_SESSION['user'] = $email;
        $_SESSION['role'] = 'user';
        header("Location: index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div class="form-card">
    <h2>Create account</h2>
    <?php if(isset($error)) echo "<div style='color:#e74c3c;margin-bottom:10px;'>$error</div>"; ?>
    <form method="POST">
        <label>Email</label>
        <input type="email" placeholder="Please enter your email" name="email" required>

        <label>Password</label>
        <input type="password" placeholder="Please enter your password" name="password" required>

        <button class="btn-primary" name="signup">Sign up</button>
    </form>
</div>
</body>
</html>
