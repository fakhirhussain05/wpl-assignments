<?php
include "db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    die("Access denied!");
}

if(!isset($_GET['id'])) die("Job ID missing!");
$id = intval($_GET['id']);

$res = mysqli_query($conn, "SELECT * FROM jobs WHERE id='$id'");
if(mysqli_num_rows($res) == 0) die("Job not found!");
$job = mysqli_fetch_assoc($res);

if(isset($_POST['update'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $company = mysqli_real_escape_string($conn, $_POST['company']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary'] ?? 'Not specified');
    $job_type = mysqli_real_escape_string($conn, $_POST['job_type']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

    mysqli_query($conn, "UPDATE jobs SET title='$title', company='$company', location='$location', description='$description', salary='$salary', job_type='$job_type', category='$category' WHERE id='$id'");
    $msg = "Job updated!";
    // refresh
    $res = mysqli_query($conn, "SELECT * FROM jobs WHERE id='$id'");
    $job = mysqli_fetch_assoc($res);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Job</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div class="form-card">
    <h2>Edit Job</h2>
    <?php if(isset($msg)) echo "<div style='color:green;margin-bottom:10px;'>$msg</div>"; ?>
    <form method="POST">
        <label>Title</label>
        <input type="text" name="title" value="<?= htmlspecialchars($job['title']) ?>" required>

        <label>Company</label>
        <input type="text" name="company" value="<?= htmlspecialchars($job['company']) ?>" required>

        <label>Location</label>
        <input type="text" name="location" value="<?= htmlspecialchars($job['location']) ?>" required>

        <label>Salary</label>
        <input type="text" name="salary" value="<?= htmlspecialchars($job['salary']) ?>">

        <label>Job Type</label>
        <select name="job_type">
            <option <?= $job['job_type']=='Full Time'?'selected':'' ?>>Full Time</option>
            <option <?= $job['job_type']=='Part Time'?'selected':'' ?>>Part Time</option>
            <option <?= $job['job_type']=='Freelance'?'selected':'' ?>>Freelance</option>
            <option <?= $job['job_type']=='Internship'?'selected':'' ?>>Internship</option>
        </select>

        <label>Category</label>
        <select name="category">
            <option <?= $job['category']=='General'?'selected':'' ?>>General</option>
            <option <?= $job['category']=='IT'?'selected':'' ?>>IT</option>
            <option <?= $job['category']=='Marketing'?'selected':'' ?>>Marketing</option>
            <option <?= $job['category']=='Design'?'selected':'' ?>>Design</option>
            <option <?= $job['category']=='Sales'?'selected':'' ?>>Sales</option>
        </select>

        <label>Description</label>
        <textarea name="description" rows="6"><?= htmlspecialchars($job['description']) ?></textarea>

        <button class="btn-primary" name="update">Update Job</button>
    </form>
</div>
</body>
</html>
