<?php
include "db.php";
$q = $_GET['q'] ?? "";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Jobs</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div style="width:90%;margin:30px auto;">
    <h2>Search results for: "<?= htmlspecialchars($q) ?>"</h2>
    <form action="search.php" method="GET" class="search-box">
        <input type="text" name="q"
               placeholder="Job title, company, or keyword..."
               value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
        <button type="submit">Search</button>
    </form>
</div>

<div class="jobs-grid">
<?php
$sql = "SELECT * FROM jobs WHERE title LIKE '%$q%' OR company LIKE '%$q%' OR description LIKE '%$q%' ORDER BY id DESC";
$res = mysqli_query($conn, $sql);

if(mysqli_num_rows($res) == 0){
    echo "<p style='width:90%;margin:30px auto;'>No jobs found.</p>";
}

while($job = mysqli_fetch_assoc($res)):
?>
    <div class="job-card">
        <div class="job-top">
            <div class="job-logo"><?= strtoupper(substr($job['company'],0,1)) ?></div>
            <div>
                <div class="job-title"><?= htmlspecialchars($job['title']) ?></div>
                <div class="job-company"><?= htmlspecialchars($job['company']) ?></div>
            </div>
        </div>

        <div class="job-location">📍 <?= htmlspecialchars($job['location']) ?></div>

        <div class="job-meta">
            <div class="meta-pill">💰 <?= htmlspecialchars($job['salary']) ?></div>
            <div class="meta-pill">🕒 <?= htmlspecialchars($job['job_type']) ?></div>
            <div class="meta-pill">🏷️ <?= htmlspecialchars($job['category']) ?></div>
        </div>

        <div class="job-description">
            <?= nl2br(htmlspecialchars(substr($job['description'], 0, 140))) ?>
            <?php if(strlen($job['description']) > 140): ?>
                <span class="dots">...</span>
                <span class="more" style="display:none;"><?= nl2br(htmlspecialchars(substr($job['description'], 140))) ?></span>
                <br>
                <a href="javascript:void(0)" class="view-more" onclick="toggleDesc(this)">Read more</a>
            <?php endif; ?>
        </div>

        <div class="card-footer">
            <div class="small">Posted: <?= $job['created_at'] ?></div>
            <div>
                <a class="apply-btn" href="apply.php?id=<?= $job['id'] ?>">Apply</a>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a class="view-btn" href="edit-job.php?id=<?= $job['id'] ?>">Edit</a>
                    <a class="view-btn" href="delete-job.php?id=<?= $job['id'] ?>" style="background:#e74c3c;">Delete</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endwhile; ?>
</div>

<script>
function toggleDesc(el){
    const more = el.previousElementSibling;
    const dots = more.previousElementSibling;
    if(more.style.display === "none"){
        more.style.display = "inline";
        dots.style.display = "none";
        el.innerText = "Show less";
    } else {
        more.style.display = "none";
        dots.style.display = "inline";
        el.innerText = "Read more";
    }
}
</script>
</body>
</html>
