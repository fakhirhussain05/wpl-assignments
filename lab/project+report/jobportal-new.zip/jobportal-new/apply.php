<?php
include "db.php";

if(!isset($_SESSION['user'])){
    header("location: ./signup.php");
}

if(!isset($_GET['id'])) die("Job ID missing!");
$job_id = intval($_GET['id']);
$job_res = mysqli_query($conn, "SELECT * FROM jobs WHERE id='$job_id'");
if(mysqli_num_rows($job_res) == 0) die("Job not found!");
$job = mysqli_fetch_assoc($job_res);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Apply for <?= htmlspecialchars($job['title']) ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div class="form-card">
    <h2>Apply for <?= htmlspecialchars($job['title']) ?></h2>

    <form method="POST" action="submit_application.php" enctype="multipart/form-data">
        <input type="hidden" name="job_id" value="<?= $job['id'] ?>">

        <label>Name</label>
        <input type="text" name="name" required>

        <label>Phone</label>
        <input type="text" name="phone" required>

        <label>Resume (PDF)</label>
        <input type="file" name="resume" accept="application/pdf" required>

        <button class="btn-primary" name="apply">Submit Application</button>
    </form>
</div>

</body>
</html>
