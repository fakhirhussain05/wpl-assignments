<?php
include "db.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>JobHunt — Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include "nav.php"; ?>

<div class="hero">
    <h1>Find Jobs That Grow Your Career</h1>
    <p>Search thousands of curated job listings and apply in seconds.</p>

    <form action="index.php" method="GET" class="search-box">
        <input type="text" name="q" placeholder="Job title, company, or keyword..." 
               value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
        <button type="submit">Search</button>
    </form>

    <p style="margin-top:10px;">
        Don't have an account? <a href="signup.php" class="signup-link">Sign Up</a>
    </p>
</div>

<form action="index.php" method="GET" class="filters">

    <select name="job_type">
        <option value="">Job Type</option>
        <option value="Full Time">Full Time</option>
        <option value="Part Time">Part Time</option>
        <option value="Internship">Internship</option>
        <option value="Remote">Remote</option>
    </select>

    <select name="category">
        <option value="">Category</option>
        <option value="IT">IT</option>
        <option value="Marketing">Marketing</option>
        <option value="Finance">Finance</option>
        <option value="Sales">Sales</option>
        <option value="Design">Design</option>
    </select>

    <input type="text" name="location" placeholder="Location">

    <select name="salary">
        <option value="">Salary</option>
        <option value="30000">30,000+</option>
        <option value="50000">50,000+</option>
        <option value="100000">100,000+</option>
    </select>

    <button type="submit">Apply Filters</button>
</form>

<div class="jobs-grid">
    <?php

    $q         = $_GET['q'] ?? "";
    $jobType   = $_GET['job_type'] ?? "";
    $category  = $_GET['category'] ?? "";
    $location  = $_GET['location'] ?? "";
    $salary    = $_GET['salary'] ?? "";

    $sql = "SELECT * FROM jobs WHERE status = 1 AND title LIKE '%$q%'";

    if(!empty($jobType))   $sql .= " AND job_type = '$jobType'";
    if(!empty($category))  $sql .= " AND category = '$category'";
    if(!empty($location))  $sql .= " AND location LIKE '%$location%'";
    if(!empty($salary))    $sql .= " AND salary >= '$salary'";

    $sql .= " ORDER BY id DESC";

    $res = mysqli_query($conn, $sql);

    if(mysqli_num_rows($res) == 0){
        echo "<p style='width:90%;margin:30px auto;'>No jobs found.</p>";
    }

    while($job = mysqli_fetch_assoc($res)):
    ?>
    <div class="job-card">
        <div>
            <div class="job-top">
                <div class="job-logo"><?= strtoupper(substr($job['company'],0,1)) ?></div>
                <div>
                    <div class="job-title"><?= htmlspecialchars($job['title']) ?></div>
                    <div class="job-company"><?= htmlspecialchars($job['company']) ?></div>
                </div>
            </div>

            <div class="job-location">📍 <?= htmlspecialchars($job['location']) ?></div>

            <div class="job-meta">
                <div class="meta-pill">💰 <?= htmlspecialchars($job['salary']) ?></div>
                <div class="meta-pill">🕒 <?= htmlspecialchars($job['job_type']) ?></div>
                <div class="meta-pill">🏷️ <?= htmlspecialchars($job['category']) ?></div>
            </div>

            <div class="job-description">
                <?= nl2br(htmlspecialchars(substr($job['description'], 0, 140))) ?>
                <?php if(strlen($job['description']) > 140): ?>
                    <span class="dots">...</span>
                    <span class="more" style="display:none;">
                        <?= nl2br(htmlspecialchars(substr($job['description'], 140))) ?>
                    </span>
                    <br>
                    <a href="javascript:void(0)" class="view-more" onclick="toggleDesc(this)">Read more</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-footer">
            <div class="small">Posted: <?= $job['created_at'] ?></div>

            <div>
                <a class="apply-btn" href="apply.php?id=<?= $job['id'] ?>">Apply</a>

                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a class="view-btn" href="edit-job.php?id=<?= $job['id'] ?>">Edit</a>
                    <a class="view-btn" style="background:#e74c3c;" 
                       href="delete-job.php?id=<?= $job['id'] ?>">Delete</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<script>
function toggleDesc(el){
    const more = el.previousElementSibling;
    const dots = more.previousElementSibling;
    if(more.style.display === "none"){
        more.style.display = "inline";
        dots.style.display = "none";
        el.innerText = "Show less";
    } else {
        more.style.display = "none";
        dots.style.display = "inline";
        el.innerText = "Read more";
    }
}
</script>

</body>
</html>
