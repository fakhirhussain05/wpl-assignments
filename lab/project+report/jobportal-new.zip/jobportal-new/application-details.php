<?php
include "db.php";
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') die("Access denied!");

if(!isset($_GET['id'])) die("Application ID missing");
$id = intval($_GET['id']);

$res = mysqli_query($conn, "SELECT applications.*, jobs.title AS job_title, jobs.company AS job_company FROM applications JOIN jobs ON applications.job_id = jobs.id WHERE applications.id='$id'");

if(mysqli_num_rows($res) == 0) die("Application not found");
$app = mysqli_fetch_assoc($res);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Application Details</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div class="container">
    <h2>Application Details</h2>

    <div class="job-card">
        <h3><?= htmlspecialchars($app['job_title']) ?> — <?= htmlspecialchars($app['job_company']) ?></h3>
        <p><b>Applicant:</b> <?= htmlspecialchars($app['name']) ?> (<?= htmlspecialchars($app['email']) ?>)</p>
        <p><b>Phone:</b> <?= htmlspecialchars($app['phone']) ?></p>
        <p><b>Applied on:</b> <?= $app['created_at'] ?></p>
        <a class="view-btn" href="uploads/<?= $app['resume'] ?>" target="_blank">Download Resume</a>
    </div>
</div>

</body>
</html>
