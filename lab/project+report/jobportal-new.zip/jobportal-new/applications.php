<?php
include "db.php";

if(!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';

if($isAdmin){
    $res = mysqli_query($conn, "SELECT applications.*, jobs.title AS job_title, jobs.company AS job_company FROM applications JOIN jobs ON applications.job_id = jobs.id WHERE applications.status = 1 ORDER BY applications.id DESC");
} else {
    $user_email = mysqli_real_escape_string($conn, $_SESSION['user']);
    $res = mysqli_query($conn, "SELECT applications.*, jobs.title AS job_title, jobs.company AS job_company FROM applications JOIN jobs ON applications.job_id = jobs.id WHERE applications.status = 1 AND applications.email='$user_email' ORDER BY applications.id DESC");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Applications</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div class="container">
    <h2>Applications</h2>

    <div class="jobs-grid" style="grid-template-columns:repeat(1,1fr);">
    <?php if(mysqli_num_rows($res) == 0): ?>
        <p>No applications found.</p>
    <?php else: ?>
        <?php while($app = mysqli_fetch_assoc($res)): ?>
            <div class="job-card">
                <div class="job-top">
                    <div class="job-logo">A</div>
                    <div>
                        <div class="job-title"><?= htmlspecialchars($app['job_title']) ?></div>
                        <div class="job-company"><?= htmlspecialchars($app['job_company']) ?></div>
                    </div>
                </div>

                <p>Applicant: <b><?= htmlspecialchars($app['name']) ?></b> (<?= htmlspecialchars($app['email']) ?>)</p>
                <p>Phone: <?= htmlspecialchars($app['phone']) ?></p>

                <div class="card-footer">
                    <div class="small">Applied: <?= $app['created_at'] ?></div>
                    <div>
                        <a class="view-btn" href="uploads/<?= $app['resume'] ?>" target="_blank">Resume</a>
                        <?php if($isAdmin): ?>
                            <a class="view-btn" href="application-details.php?id=<?= $app['id'] ?>" style="background:#28a745;">View</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
    </div>
</div>

</body>
</html>
