<?php
include "db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Admins only!");
}

if(!isset($_GET['id'])){
    die("Application ID missing!");
}

$id = $_GET['id'];

$query = "UPDATE applications SET status = 0 WHERE id = '$id'";
mysqli_query($conn, $query);

header("Location: applications.php");
exit;
?>