<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "jobportal-new");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
