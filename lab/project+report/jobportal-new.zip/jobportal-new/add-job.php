<?php
include "db.php";

if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    die("Access denied! Only admin can add jobs.");
}

if(isset($_POST['save'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $company = mysqli_real_escape_string($conn, $_POST['company']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary'] ?? 'Not specified');
    $job_type = mysqli_real_escape_string($conn, $_POST['job_type'] ?? 'Full Time');
    $category = mysqli_real_escape_string($conn, $_POST['category'] ?? 'General');

    mysqli_query($conn, "INSERT INTO jobs(title,company,location,description,salary,job_type,category)
                         VALUES('$title','$company','$location','$description','$salary','$job_type','$category')");
    $msg = "Job added successfully!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Job</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "nav.php"; ?>

<div class="form-card">
    <h2>Add New Job</h2>
    <?php if(isset($msg)) echo "<div style='color:green;margin-bottom:10px;'>$msg</div>"; ?>
    <form method="POST">
        <label>Title</label>
        <input type="text" name="title" required>

        <label>Company</label>
        <input type="text" name="company" required>

        <label>Location</label>
        <input type="text" name="location" required>

        <label>Salary</label>
        <input type="text" name="salary">

        <label>Job Type</label>
        <select name="job_type">
            <option>Full Time</option>
            <option>Part Time</option>
            <option>Freelance</option>
            <option>Internship</option>
            <option>Remote</option>

        </select>

        <label>Category</label>
        <select name="category">
            <option>General</option>
            <option>IT</option>
            <option>Marketing</option>
            <option>Design</option>
            <option>Sales</option>
        </select>

        <label>Description</label>
        <textarea name="description" rows="6" required></textarea>

        <button class="btn-primary" name="save">Save Job</button>
    </form>
</div>
</body>
</html>
