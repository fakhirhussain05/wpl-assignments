<?php
include "db.php";
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') { die("Access denied"); }
if(!isset($_GET['id'])) die("Job ID missing");
$id = intval($_GET['id']);
mysqli_query($conn, "UPDATE jobs SET status=0 WHERE id='$id';
");
header("Location: index.php");
exit;
?>
