<?php
?>
<link rel="stylesheet" href="style.css">

<nav class="navbar">
    <div class="nav-container">
        <div class="logo">Hussain's Job<span>Hunt</span></div>

        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="search.php">All Jobs</a></li>

            <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <li><a href="add-job.php">Add Job</a></li>
                <li><a href="applications.php">Applications</a></li>
            <?php endif; ?>

            <?php if(isset($_SESSION['user'])): ?>
                <li><a href="applications.php">My Applications</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Signup</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
