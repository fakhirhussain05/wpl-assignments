<?php
include "db.php";

if(!isset($_SESSION['user'])) {
    die("Please login to apply!");
}

if(isset($_POST['apply'])){
    $job_id = intval($_POST['job_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_SESSION['user']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);

    if(isset($_FILES['resume']) && $_FILES['resume']['error'] == 0){
        $fname = time() . "_" . basename($_FILES['resume']['name']);
        $target = __DIR__ . "/uploads/" . $fname;
        move_uploaded_file($_FILES['resume']['tmp_name'], $target);

        mysqli_query($conn, "INSERT INTO applications(job_id,name,email,phone,resume) 
                             VALUES('$job_id','$name','$email','$phone','$fname')");

        $msg = "Application submitted!";
    } else {
        $msg = "Please upload your resume!";
    }
    header("Location: applications.php");
    exit;
}
?>
